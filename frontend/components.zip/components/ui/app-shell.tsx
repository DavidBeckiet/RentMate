"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useId, useState, type ReactNode } from "react";
import { useAuth } from "../../lib/auth/auth-provider";
import { Button } from "./button";
import { RentMateMark } from "./rentmate-mark";
import styles from "./app-shell.module.css";

const anonymousNavigationLinks = [
  { href: "/login", label: "Đăng nhập", emphasis: "normal" },
  { href: "/register/tenant", label: "Đăng ký tìm phòng", emphasis: "quiet" },
  { href: "/register/landlord", label: "Đăng ký cho thuê", emphasis: "quiet" }
] as const;

const navigationLinkClass =
  "relative inline-flex min-h-11 items-center rounded-xl px-3.5 text-xs font-bold text-slate-600 transition-all duration-200 hover:bg-sky-50 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 aria-[current=page]:bg-sky-50 aria-[current=page]:font-bold aria-[current=page]:text-sky-600";

const footerLinkClass =
  "text-sm text-slate-400 transition-colors hover:text-sky-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-md px-1";

export function AppShell({ children }: Readonly<{ children: ReactNode }>) {
  const pathname = usePathname();
  const router = useRouter();
  const menuId = useId();
  const [menuOpen, setMenuOpen] = useState(false);
  const [headerScrolled, setHeaderScrolled] = useState(false);
  const [logoutPending, setLogoutPending] = useState(false);
  const [logoutRequested, setLogoutRequested] = useState(false);
  const { status, user, error, refresh, logout } = useAuth();
  const landlordHref = status === "authenticated" && user?.role === "LANDLORD" ? "/landlord" : "/register/landlord";

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    const updateHeader = () => setHeaderScrolled(window.scrollY > 18);
    updateHeader();
    window.addEventListener("scroll", updateHeader, { passive: true });
    return () => window.removeEventListener("scroll", updateHeader);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [menuOpen]);

  useEffect(() => {
    if (logoutRequested && status === "anonymous") {
      setLogoutRequested(false);
      router.replace("/");
    }
  }, [logoutRequested, router, status]);

  const handleLogout = async () => {
    if (logoutPending) return;
    setLogoutPending(true);
    setLogoutRequested(true);
    try {
      await logout();
    } finally {
      setLogoutPending(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-50/60 pb-16 text-slate-900 antialiased md:pb-0">
      <a
        href="#main-content"
        className="fixed left-4 top-4 z-50 -translate-y-24 rounded-xl bg-sky-600 px-5 py-3 font-semibold text-white shadow-card-elevated transition-transform focus:translate-y-0"
      >
        Bỏ qua đến nội dung chính
      </a>

      <header className={styles.siteHeader} data-scrolled={headerScrolled}>
        <div className="rm-page-container flex min-h-[4.75rem] items-center justify-between gap-4">
          <Link
            href="/"
            aria-label="RentMate"
            className="group inline-flex shrink-0 items-center gap-2.5 rounded-2xl p-1 text-xl font-black tracking-tight text-slate-900 transition-all hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brandBlue-500 to-sky-600 text-white shadow-md shadow-brandBlue-500/30 transition-transform group-hover:scale-105">
              <RentMateMark className="h-5 w-5 text-white" />
            </div>
            <span>
              <span className="block leading-none">
                Rentmate<span className="text-brandBlue-500">.vn</span>
              </span>
              <small className="mt-1 block text-[9px] font-black uppercase tracking-wider text-brandBlue-600">
                #1 THUÊ NHÀ VIỆT NAM
              </small>
            </span>
          </Link>

          <button
            type="button"
            className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-xl border border-slate-200 bg-white/90 px-3 text-slate-700 transition-all hover:border-brandBlue-500 hover:bg-brandBlue-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brandBlue-500 md:hidden"
            aria-expanded={menuOpen}
            aria-controls={menuId}
            aria-label={menuOpen ? "Đóng menu điều hướng" : "Mở menu điều hướng"}
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span className="sr-only">{menuOpen ? "Đóng" : "Mở"}</span>
            <span aria-hidden="true" className="grid gap-1.5">
              <span
                className={`block h-0.5 w-5 bg-current transition-transform duration-200 ${menuOpen ? "translate-y-2 rotate-45" : ""}`}
              />
              <span className={`block h-0.5 w-5 bg-current transition-opacity duration-200 ${menuOpen ? "opacity-0" : ""}`} />
              <span
                className={`block h-0.5 w-5 bg-current transition-transform duration-200 ${menuOpen ? "-translate-y-2 -rotate-45" : ""}`}
              />
            </span>
          </button>

          <nav
            id={menuId}
            aria-label="Điều hướng chính"
            className={`absolute left-4 right-4 top-[calc(100%+0.5rem)] z-40 flex max-h-0 origin-top -translate-y-2 scale-[0.98] flex-col gap-1.5 overflow-hidden rounded-3xl border border-slate-200/90 bg-white/95 p-4 opacity-0 shadow-card-elevated backdrop-blur-2xl transition-all duration-300 ${
              menuOpen
                ? "max-h-[42rem] translate-y-0 scale-100 opacity-100"
                : "pointer-events-none md:pointer-events-auto"
            } md:static md:max-h-none md:translate-y-0 md:scale-100 md:flex-row md:items-center md:gap-1 md:overflow-visible md:border-0 md:bg-transparent md:p-0 md:opacity-100 md:shadow-none`}
          >
            <Link
              href="/"
              aria-current={pathname === "/" ? "page" : undefined}
              className={navigationLinkClass}
              onClick={() => setMenuOpen(false)}
            >
              Trang chủ
            </Link>
            <Link
              href="/?sort=newest"
              aria-current={pathname === "/" || pathname.startsWith("/listings") ? "page" : undefined}
              className={navigationLinkClass}
              onClick={() => setMenuOpen(false)}
            >
              Phòng trọ
            </Link>
            <Link
              href="/?sort=newest"
              className={`${navigationLinkClass} inline-flex items-center gap-1`}
              onClick={() => setMenuOpen(false)}
            >
              <span>Tìm gần bạn</span>
              <span className="rounded bg-rose-500 px-1 py-0.2 text-[8px] font-black uppercase text-white">
                Mới
              </span>
            </Link>

            {(status === "anonymous" || status === "error") &&
              anonymousNavigationLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  aria-current={pathname === link.href ? "page" : undefined}
                  className={`${navigationLinkClass} ${
                    link.emphasis === "quiet"
                      ? "font-semibold text-brandBlue-600 hover:bg-brandBlue-50"
                      : ""
                  }`}
                  onClick={() => setMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}

            {status === "loading" && (
              <span className="inline-flex min-h-11 items-center px-4 text-xs font-semibold text-slate-400 animate-pulse" aria-live="polite">
                Đang kiểm tra tài khoản…
              </span>
            )}

            {status === "error" && (
              <div className="flex flex-wrap items-center gap-2 p-2" role="alert">
                <span className="text-xs font-medium text-rose-600">Không thể kiểm tra tài khoản.</span>
                <button
                  type="button"
                  className="rounded-lg px-2.5 py-1 text-xs font-bold text-brandBlue-600 hover:bg-brandBlue-50"
                  onClick={() => void refresh()}
                >
                  Thử lại
                </button>
              </div>
            )}

            {status === "authenticated" && user && (
              <div className="flex flex-col gap-2 md:flex-row md:items-center">
                {user.role === "TENANT" ? (
                  <Link
                    href="/favorites"
                    aria-current={pathname === "/favorites" ? "page" : undefined}
                    className={navigationLinkClass}
                    onClick={() => setMenuOpen(false)}
                  >
                    Tin đã lưu
                  </Link>
                ) : null}
                {user.role === "LANDLORD" ? (
                  <>
                    <Link
                      href="/landlord"
                      aria-current={
                        pathname === "/landlord" || pathname.startsWith("/landlord/listings/")
                          ? "page"
                          : undefined
                      }
                      className={navigationLinkClass}
                      onClick={() => setMenuOpen(false)}
                    >
                      Tin của tôi
                    </Link>
                    <Link
                      href="/landlord/profile"
                      aria-current={pathname === "/landlord/profile" ? "page" : undefined}
                      className={navigationLinkClass}
                      onClick={() => setMenuOpen(false)}
                    >
                      Hồ sơ
                    </Link>
                  </>
                ) : null}
                {user.role === "ADMIN" ? (
                  <>
                    <Link
                      href="/admin"
                      aria-current={
                        pathname === "/admin" || pathname.startsWith("/admin/listings/")
                          ? "page"
                          : undefined
                      }
                      className={navigationLinkClass}
                      onClick={() => setMenuOpen(false)}
                    >
                      Kiểm duyệt
                    </Link>
                    <Link
                      href="/admin/users"
                      aria-current={pathname === "/admin/users" ? "page" : undefined}
                      className={navigationLinkClass}
                      onClick={() => setMenuOpen(false)}
                    >
                      Người dùng
                    </Link>
                  </>
                ) : null}

                <div className="my-2 border-t border-slate-100 md:my-0 md:ml-3 md:border-l md:border-t-0 md:pl-4">
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col">
                      <span className="max-w-[10rem] truncate text-xs font-bold text-slate-800">{user.email}</span>
                      <span className="inline-flex w-fit items-center gap-1 rounded-full bg-brandBlue-50 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-brandBlue-700 border border-brandBlue-100">
                        {user.role}
                      </span>
                    </div>
                    <Button
                      variant="secondary"
                      pending={logoutPending}
                      pendingLabel="Đang đăng xuất…"
                      className="!min-h-9 !py-1.5 !px-3.5 !text-xs font-semibold"
                      onClick={() => void handleLogout()}
                    >
                      Đăng xuất
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {status === "authenticated" && error && (
              <p className="p-2 text-xs font-medium text-rose-600" role="alert">
                Đăng xuất chưa thành công. Vui lòng thử lại.
              </p>
            )}
          </nav>
          <Link
            href={landlordHref}
            className="hidden min-h-10 shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-brandBlue-500 to-sky-500 px-4 py-2.5 text-xs font-extrabold text-white shadow-lg shadow-brandBlue-500/25 transition hover:from-brandBlue-600 hover:to-sky-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brandBlue-500 sm:inline-flex"
            onClick={() => setMenuOpen(false)}
          >
            <span aria-hidden="true" className="text-base leading-none">+</span>
            <span>Đăng tin miễn phí</span>
          </Link>
        </div>
      </header>

      <main
        id="main-content"
        className={`${
          pathname === "/"
            ? "flex-1"
            : "rm-page-container flex-1 py-8 sm:py-10 lg:py-12"
        }`}
      >
        {children}
      </main>

      <footer className="mt-20 border-t border-slate-800 bg-heroDark-950 text-slate-200">
        <div className="rm-page-container grid gap-10 py-16 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-2xl font-black tracking-tight text-white">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-brandBlue-500 text-white shadow-md shadow-brandBlue-500/30">
                <RentMateMark className="h-5 w-5 text-white" />
              </div>
              Rentmate<span className="text-brandBlue-500">.vn</span>
            </div>
            <p className="text-xs sm:text-sm leading-relaxed text-slate-400">
              Nền tảng kết nối trực tiếp giữa người tìm phòng và chủ nhà trọ tại Việt Nam. Tìm kiếm nhanh, đúng nhu cầu, dữ liệu minh bạch tuyệt đối.
            </p>
            <div className="flex flex-wrap gap-3 text-xs font-semibold text-sky-400 pt-1">
              <span>✦ Tìm kiếm thông minh</span>
              <span>✦ Vị trí xấp xỉ an toàn</span>
              <span>✦ Miễn phí 100%</span>
            </div>
          </div>

          <div>
            <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Khám phá khu vực</h2>
            <nav className="mt-4 flex flex-col gap-2.5" aria-label="Khám phá RentMate">
              <Link href="/?sort=newest" className={footerLinkClass}>Phòng trọ TP. Hồ Chí Minh</Link>
              <Link href="/?sort=newest" className={footerLinkClass}>Phòng trọ Hà Nội</Link>
              <Link href="/?sort=newest" className={footerLinkClass}>Phòng trọ Bình Dương</Link>
              <Link href="/?sort=newest" className={footerLinkClass}>Phòng trọ Cần Thơ</Link>
            </nav>
          </div>

          <div>
            <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Hỗ trợ khách hàng</h2>
            <nav className="mt-4 flex flex-col gap-2.5" aria-label="Tài khoản RentMate">
              <Link href="/login" className={footerLinkClass}>Đăng nhập hệ thống</Link>
              <Link href="/register/tenant" className={footerLinkClass}>Đăng ký người tìm phòng</Link>
              <Link href="/register/landlord" className={footerLinkClass}>Đăng ký chủ nhà cho thuê</Link>
              <Link href="/?sort=newest" className={footerLinkClass}>Quy chế hoạt động</Link>
            </nav>
          </div>

          <div>
            <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Liên hệ Rentmate</h2>
            <div className="mt-4 space-y-2 text-xs text-slate-400">
              <p><strong className="text-white">Hotline hỗ trợ:</strong> 0909.123.456 (8:00 - 21:00)</p>
              <p><strong className="text-white">Email:</strong> support@rentmate.vn</p>
              <p><strong className="text-white">Địa chỉ:</strong> Khu Công nghệ cao, TP. Thủ Đức, TP.HCM</p>
              <div className="pt-2">
                <span className="inline-block rounded-md bg-slate-900 border border-slate-800 px-2.5 py-1 text-[11px] text-slate-300">
                  Phát triển bởi <strong className="text-brandBlue-400">RentMate Tech Team</strong>
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-900 bg-heroDark-950">
          <div className="rm-page-container flex flex-col items-center justify-between gap-4 py-6 text-xs text-slate-500 sm:flex-row">
            <p>© {new Date().getFullYear()} Rentmate.vn. Tất cả quyền được bảo lưu.</p>
            <p className="text-slate-500">Nền tảng tìm phòng trọ trực tiếp #1 Việt Nam</p>
          </div>
        </div>
      </footer>

      {/* Floating Mobile Bottom Navigation Bar */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t border-slate-200 bg-white/95 backdrop-blur-md px-3 py-2 shadow-2xl md:hidden"
        aria-label="Điều hướng nhanh"
      >
        <Link
          href="/"
          className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
            pathname === "/" ? "text-brandBlue-500" : "text-slate-500"
          }`}
        >
          <RentMateMark className="h-5 w-5" />
          <span>Trang chủ</span>
        </Link>
        <Link
          href="/?sort=newest"
          className="flex flex-col items-center gap-1 text-[10px] font-bold text-slate-500"
        >
          <span className="text-base leading-5">🔍</span>
          <span>Gần bạn</span>
        </Link>
        <Link
          href={landlordHref}
          className="flex flex-col items-center gap-1 text-[10px] font-bold text-brandBlue-500 -mt-3"
        >
          <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-tr from-brandBlue-500 to-sky-400 text-lg leading-none text-white shadow-lg shadow-brandBlue-500/30">
            +
          </span>
          <span>Đăng tin</span>
        </Link>
        {status === "authenticated" && user?.role === "TENANT" ? (
          <Link
            href="/favorites"
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              pathname === "/favorites" ? "text-brandBlue-500" : "text-slate-500"
            }`}
          >
            <span className="text-base leading-5">❤️</span>
            <span>Yêu thích</span>
          </Link>
        ) : status === "authenticated" && user?.role === "LANDLORD" ? (
          <Link
            href="/landlord"
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              pathname === "/landlord" ? "text-brandBlue-500" : "text-slate-500"
            }`}
          >
            <span className="text-base leading-5">🏠</span>
            <span>Tin của tôi</span>
          </Link>
        ) : (
          <Link
            href="/login"
            className="flex flex-col items-center gap-1 text-[10px] font-bold text-slate-500"
          >
            <span className="text-base leading-5">👤</span>
            <span>Tài khoản</span>
          </Link>
        )}
        {status === "authenticated" && user?.role === "ADMIN" ? (
          <Link
            href="/admin"
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              pathname.startsWith("/admin") ? "text-brandBlue-500" : "text-slate-500"
            }`}
          >
            <span className="text-base leading-5">⚡</span>
            <span>Admin</span>
          </Link>
        ) : null}
      </nav>
    </div>
  );
}

