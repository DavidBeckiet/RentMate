import Link from "next/link";
import { FavoriteSaveControl } from "../favorites/favorite-save-control";
import type { PublicListingSummary } from "../../types/api";
import { formatAreaSqm, formatDistanceKm } from "./format";
import {
  ListingAmenityChips,
  ListingCardShell,
  ListingImage,
  ListingMetadata,
  ListingPrice
} from "./listing-presentation";
import styles from "./listing-card.module.css";

export interface ListingCardProps {
  readonly listing: PublicListingSummary;
  readonly showFavorite?: boolean;
}

export function ListingCard({ listing, showFavorite = false }: ListingCardProps) {
  return (
    <ListingCardShell>
      <div className={`${styles.listingCard} relative h-full`}>
      <Link href={`/listings/${listing.id}`} className="flex h-full flex-col focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-sky-700">
        <div className="relative">
          <ListingImage
            image={listing.coverImage}
            title={listing.title}
            sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
            className="aspect-[4/3]"
          />
          <div className="rm-image-meta">
            <span className="rm-image-meta-badge">{listing.propertyType.label}</span>
            {listing.distanceKm !== undefined ? <span>{formatDistanceKm(listing.distanceKm)}</span> : <span aria-hidden="true" />}
          </div>
        </div>
        <div className="min-w-0 p-4 sm:p-5">
          <ListingPrice monthlyRent={listing.monthlyRent} />
          <h2 className="rm-listing-title mt-3 text-lg font-semibold leading-6 text-rent-ink group-hover:text-sky-800">{listing.title}</h2>
          <ListingMetadata className="mt-3">
            {formatAreaSqm(listing.roomAreaSqm)} · {listing.propertyType.label}
          </ListingMetadata>
          <p className="mt-1 flex items-center gap-1.5 text-sm font-medium text-rent-secondary">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-4 w-4 shrink-0 text-sky-700"><path d="M12 21s7-6.1 7-12a7 7 0 1 0-14 0c0 5.9 7 12 7 12Z" /><circle cx="12" cy="9" r="2.25" /></svg>
            <span className="truncate">{listing.areaName}</span>
          </p>
          <div className="mt-4">
            <ListingAmenityChips amenities={listing.amenities} />
          </div>
        </div>
      </Link>
      {showFavorite ? <div className="absolute right-3 top-3 z-10"><FavoriteSaveControl listingId={String(listing.id)} compact /></div> : null}
      </div>
    </ListingCardShell>
  );
}
