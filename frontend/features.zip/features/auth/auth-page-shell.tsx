"use client";

import { useRouter } from "next/navigation";
import { useEffect, useId, type ReactNode } from "react";
import { EmptyState, LoadingState } from "../../components/ui/feedback-states";
import { RentMateMark } from "../../components/ui/rentmate-mark";
import { useAuth } from "../../lib/auth/auth-provider";
import type { UserRole } from "../../types/api";
import styles from "./auth-page-shell.module.css";

export interface AuthPageShellProps {
  readonly title: string;
  readonly description: string;
  readonly children: ReactNode;
  readonly footer: ReactNode;
  readonly requiredRole?: UserRole;
  readonly successDestination?: string;
  readonly wrongRoleMessage?: string;
}

export function AuthPageShell({
  title,
  description,
  children,
  footer,
  requiredRole,
  successDestination = "/",
  wrongRoleMessage = "Tài khoản này không thể truy cập trang đăng nhập này."
}: AuthPageShellProps) {
  const router = useRouter();
  const { status, user } = useAuth();
  const headingId = useId();

  useEffect(() => {
    if (status === "authenticated" && user && (!requiredRole || user.role === requiredRole)) {
      router.replace(successDestination);
    }
  }, [requiredRole, router, status, successDestination, user]);

  if (status === "loading" || (status === "authenticated" && user && (!requiredRole || user.role === requiredRole))) {
    return (
      <div className="mx-auto w-full max-w-md py-12">
        <LoadingState message={status === "loading" ? "Đang kiểm tra tài khoản…" : "Đang chuyển hướng…"} />
      </div>
    );
  }

  if (status === "authenticated") {
    return (
      <div className="mx-auto w-full max-w-md py-12">
        <EmptyState title={wrongRoleMessage} description="Hãy đăng xuất và dùng đúng tài khoản để tiếp tục." />
      </div>
    );
  }

  return (
    <section aria-labelledby={headingId} className={`${styles.authShell} rm-auth-shell max-w-md lg:max-w-5xl my-6`}>
      <div className="rm-auth-visual">
        <div className="relative z-10 flex h-full flex-col justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/20 backdrop-blur-md text-white">
              <RentMateMark className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-black tracking-tight">RentMate</span>
          </div>

          <div className="mt-auto max-w-md space-y-4 pt-16">
            <span className="rm-eyebrow border-white/20 bg-white/10 text-white backdrop-blur-md">
              MINH BẠCH & TIN CẬY
            </span>
            <h2 className="text-2xl font-black leading-tight sm:text-3xl text-white">
              Nơi ở phù hợp bắt đầu từ thông tin rõ ràng.
            </h2>
            <p className="text-sm font-medium text-teal-100/90 leading-relaxed">
              Khám phá tin công khai và quản lý thông tin thuê phòng trong một không gian dễ theo dõi.
            </p>
          </div>
        </div>
      </div>

      <div className="rm-auth-form-panel p-8 sm:p-12">
        <header className="space-y-2">
          <h1 id={headingId} className="text-3xl font-black text-slate-900 tracking-tight">{title}</h1>
          <p className="text-sm font-medium leading-relaxed text-slate-600">{description}</p>
        </header>
        <div className="mt-8">{children}</div>
        <footer className="mt-8 border-t border-slate-200/80 pt-6 text-sm font-medium text-slate-600">{footer}</footer>
      </div>
    </section>
  );
}
